try:
	import requests,re,json
	from requests.packages.urllib3.exceptions import InsecureRequestWarning
	requests.packages.urllib3.disable_warnings(InsecureRequestWarning)
except:
	print(" [+] Command: pip install requests")
from os import system
from platform import system as osname
def clear():
	if osname() == "Linux":
		system('clear')
	else:
		system('cls')
try:
	open("zone-h.txt","a")
	open("defacers.txt","a")
except:
	exit()
red = '\x1b[1;31m'
r = '\x1b[31m'
g = '\x1b[32m'
y = '\x1b[33m'
b = '\x1b[34m'
m = '\x1b[35m'
c = '\x1b[36m'
w = '\x1b[37m'
logo = """   _____       _       _         _ _      __ ____ ____ ______ 
  / ____|     | |     | |       | (_)    /_ |___ \___ \____  |
 | (___   __ _| | __ _| |__   __| |_ _ __ | | __) |__) |  / / 
  \___ \ / _` | |/ _` | '_ \ / _` | | '_ \| ||__ <|__ <  / /  
  ____) | (_| | | (_| | | | | (_| | | | | | |___) |__) |/ /   
 |_____/ \__,_|_|\__,_|_| |_|\__,_|_|_| |_|_|____/____//_/                                                              """
def Ret(x):
	try:
		return raw_input(x)
	except:
		return input(x)
headers = {'User-Agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_10_1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/39.0.2171.95 Safari/537.36'}
def rez(url,exploit,n):
	if "|" in exploit:
		arr = exploit.split("|")
		if n == "1":
			print(w+" ["+g+"+"+w+"] "+g+arr[0]+": "+w+url+y+" | "+arr[1].strip()+" | "+arr[2].strip()+g+" [YES]")
		else:
			print(w+" ["+r+"+"+w+"] "+r+arr[0]+": "+w+url+y+" | "+arr[1].strip()+" | "+arr[2].strip()+r+" [NO]")
	else:
		if n == "1":
			print(w+" ["+g+"+"+w+"] "+g+exploit+": "+w+url+g+" [YES]")
		else:
			print(w+" ["+r+"+"+w+"] "+r+exploit+": "+w+url+r+" [NO]")
def SETCookies(msg=""):
	clear()
	print(w+msg+r+logo+"""\n{}	Author:{} Black_Phish\n	{}Name: {}Grab Weblist To Ip\n""".format(y,c,y,c))
	ZHE = Ret(g+" ~"+w+" # ZHE: "+r)
	PHPSESSID =  Ret(g+" ~"+w+" # PHPSESSID: "+r)
	data = json.dumps({"ZHE":ZHE,"PHPSESSID":PHPSESSID},indent=2)
	try:
		open(".cookies.log","w").write(data)
	except Exception as e:
		print(e)
	Ret(g+' - '+c+'Message: '+w+'Cookies setup successful. Press enter to continue!')
	return data;
try:
	cookies = json.loads(open(".cookies.log","r").read())
except:
	cookies = json.loads(SETCookies("Please SETUP Zone-H Cookies\n"))
try:
	import concurrent.futures
	xxx = True
except:
	from multiprocessing.pool import ThreadPool
	xxx = False
def SpeedX(check,list,th):
	if xxx == True:
		try:
			with concurrent.futures.ThreadPoolExecutor(int(th)) as executor:
				executor.map(check,list)
		except Exception as e:
			print(e)
	else:
		pool = ThreadPool(int(th))
		pool.map(check,list)
		pool.close()
		pool.join()
def get(url):
	while True:
		try:
			return requests.get(url,cookies=cookies,headers=headers).content.decode('utf-8')
			break
		except:
			pass
def ZoneH(url):
	print(w+" - "+c+"URL: "+g+url)
	try:
		req = get(url)
		if '<html><body>-<script type="text/javascript"' in req:
			return False
		if '<input type="text" name="captcha" value=""><input type="submit">' in req:
			Ret(g+' - '+c+'Message: '+w+'Open Browser & Solve Captcha.')
			ZoneH(url)
			return 0
		pattern = """<td>(.*?)
							</td>"""
		regx = re.findall(pattern,req)
		if len(regx) == 0:
			return "dump"
		for url in regx:
			url = url.replace("http://","")
			url = url.replace('https://','')
			url = url.split("/")[0]
			if url not in open("zone-h.txt","r").read():
				rez(url,"Added","1")
				open("zone-h.txt","a").write(url+"\n")
			else:
				rez(url,"Added","h1")
		defacers = re.findall('archive/notifier\=(.*?)">',req)
		for name in defacers:
			if name not in open("defacers.txt","r").read():
				open("defacers.txt","a").write(name+"\n")
	except Exception as e:
		print(e)
pagelist = []
def Run():
 clear()
 print(r+logo+"""\n    {}I Don't Aspect Any Responsibility For Bad Ussage!{}\n\n Author: {}The Black_Phish{}\n Name: {}Zone-H BOT{}\n Application: {}Python 2.7 & 3.9 Supported{}\n Chose a Tool:{}\n  1. Zone-H Archive Grabber\n  2. Zone-H Onhold Grabber\n  3. Mass Notifier Grabber\n  4. Setup Zone-H Cookies\n  5. Mass Add http In Url
 """.format(g,y,c,y,c,y,c,m,w))
 try:
 	cmd = Ret(g+" [{}root{}@{}salahdin{}:{}~{}]{}# {}".format(g,r,y,g,c,g,m,r))
 	if cmd == "1":
 		clear()
 		print(r+logo+"""\n{}	Author:{} Black_Phish\n	{}Name: {}ZoneH Archive Grabber\n""".format(y,c,y,c))
 		for i in range(1,51):
 			pagelist.append("http://zone-h.org/archive/page="+str(i))
 	elif cmd == "2":
 		clear()
 		print(r+logo+"""\n{}	Author:{} Black_Phish\n	{}Name: {}ZoneH Onhold Grabber\n""".format(y,c,y,c))
 		for i in range(1,51):
 			pagelist.append("http://zone-h.org/archive/published=0/page="+str(i))
 	elif cmd == "3":
 		clear()
 		print(r+logo+"""\n{}	Author:{} Black_Phish\n	{}Name: {}ZoneH Mass Notifier\n""".format(y,c,y,c))
 		try:
 			defacers = open(Ret(g+" ~"+w+" # Defacer Name List: "+r),"r").read().splitlines()
 		except:
 			defacers = ["Black_Phish"]
 		for name in defacers:
 			for i in range(1,51):
 				page = "http://zone-h.org/archive/notifier="+name+"/page="+str(i)
 				zh = ZoneH(page)
 				if zh == False:
 					cookies = json.loads(SETCookies("Please SETUP Zone-H Cookies\n"))
 				if zh == "dump":
 					break
 		Run()
 	elif cmd == "4":
 		cookies = json.loads(SETCookies("Please SETUP Zone-H Cookies\n"))
 		Run()
 	elif cmd == "5":
 		clear()
 		print(r+logo+"""\n{}	Author:{} Black_Phish\n	{}Name: {}Mass Add http Url\n""".format(y,c,y,c))
 		try:
 			sites = open(Ret(g+" ~"+w+" # Enter SiteList: "+r),"r").read().splitlines()
 			f = open(Ret(g+" ~"+w+" # Save File: "+r),"a")
 			for url in sites:
 				f.write("http://"+url+"\n")
 			Ret(g+' - '+c+'Message: '+w+'http Added Successful!')
 			Run()
 		except:
 			exit()
 	else:
 		Run()
 	if len(pagelist) != 0:
 		for page in pagelist:
 			zh = ZoneH(page)
 			if zh == False:
 				cookies = json.loads(SETCookies("Please SETUP Zone-H Cookies\n"))
 			if zh == "dump":
 				break
 	Run()
 except Exception as e:
 	print(e)
 	exit()
while True:
	Run()