try:
	import requests,re,json
	from requests.packages.urllib3.exceptions import InsecureRequestWarning
	requests.packages.urllib3.disable_warnings(InsecureRequestWarning)
except:
	print(" [+] Command: pip install requests")
from urllib.parse import quote
from os import system
from platform import system as osname
from random import choice
def clear():
	if osname() == "Linux":
		system('clear')
	else:
		system('cls')
red = '\x1b[1;31m'
r = '\x1b[31m'
g = '\x1b[32m'
y = '\x1b[33m'
b = '\x1b[34m'
m = '\x1b[35m'
c = '\x1b[36m'
w = '\x1b[37m'
logo = """   _____       _       _         _ _      __ ____ ____ ______ 
  / ____|     | |     | |       | (_)    /_ |___ \___ \____  |
 | (___   __ _| | __ _| |__   __| |_ _ __ | | __) |__) |  / / 
  \___ \ / _` | |/ _` | '_ \ / _` | | '_ \| ||__ <|__ <  / /  
  ____) | (_| | | (_| | | | | (_| | | | | | |___) |__) |/ /   
 |_____/ \__,_|_|\__,_|_| |_|\__,_|_|_| |_|_|____/____//_/                                                              """
def Ret(x):
	try:
		return raw_input(x)
	except:
		return input(x)
def rez(url,exploit,n):
	if "|" in exploit:
		arr = exploit.split("|")
		if n == "1":
			print(w+" ["+g+"+"+w+"] "+g+arr[0]+": "+w+url+y+" | "+arr[1].strip()+" | "+arr[2].strip()+g+" [YES]")
		else:
			print(w+" ["+r+"+"+w+"] "+r+arr[0]+": "+w+url+y+" | "+arr[1].strip()+" | "+arr[2].strip()+r+" [NO]")
	else:
		if n == "1":
			print(w+" ["+g+"+"+w+"] "+g+exploit+": "+w+url+g+" [YES]")
		else:
			print(w+" ["+r+"+"+w+"] "+r+exploit+": "+w+url+r+" [NO]")
try:
	import concurrent.futures
	xxx = True
except:
	from multiprocessing.pool import ThreadPool
	xxx = False
def SpeedX(check,list,th):
	if xxx == True:
		try:
			with concurrent.futures.ThreadPoolExecutor(int(th)) as executor:
				executor.map(check,list)
		except Exception as e:
			print(e)
	else:
		pool = ThreadPool(int(th))
		pool.map(check,list)
		pool.close()
		pool.join()
headers = {
	"Host":"www.google.com",
	"Connection":"keep-alive",
	"Upgrade-Insecure-Requests":"1",
	"User-Agent":"Mozilla/5.0 (Linux; Android 11; RMX2195 Build/RKQ1.201217.002; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/94.0.4606.85 Mobile Safari/537.36",
	"Accept":"text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9",
	"X-Requested-With":"acr.browser.barebones",
	"Sec-Fetch-Site":"same-origin",
	"Sec-Fetch-Mode":"navigate",
	"Sec-Fetch-User":"?1",
	"Sec-Fetch-Dest":"document",
	"Referer":"https://www.google.com/",
	"Accept-Encoding":"gzip, deflate",
	"Accept-Language":"en-US,en;q=0.9"
}
sess = requests.session()
def Google(url):
	print(w+" - "+c+"URL: "+g+url)
	while True:
		try:
			prox = choice(proxylist)
			proxies = {"http": "http://"+prox,"https": "http://"+prox}
			req = sess.get(url,headers=headers,proxies=proxies).content.decode('utf-8')
			break
		except Exception as e:
			pass
	input(req)
	pattern = '/url\?q=(.*?)"'
	regx = re.findall(pattern,req)
	for url in regx:
		url = url.replace('http://','').replace('https://','').split('/')[0]
		if url not in open(filename,"r").read():
			Rez(url,"Added","1")
			open(filename,"a").write(url+"\n")
		else:
			Rez(url,"Added","h1")
Dorks = []
clear()
print(r+logo+"""\n{}	Author:{} Black_Phish\n	{}Name: {}Google Domain Grabber\n""".format(y,c,y,c))
try:
	proxylist = open('proxy.txt','r').read().splitlines()
except:
	pass
try:
	dorklist = open(Ret(g+" ~"+w+" # DorkList: "+r),"r").read().splitlines()
	page = int(Ret(g+" ~"+w+" # Page No: "+r))*10+10
	filename = Ret(g+" ~"+w+" # Save File: "+r)
	open(filename,"a")
	th = int(Ret(g+" ~"+w+" # Thread: "+r))
except:
	exit()
for dork in dorklist:
	for i in range(0,page,10):
		Dorks.append("https://www.google.com/search?q="+quote(dork)+"&start="+str(i))
SpeedX(Google,Dorks,th)