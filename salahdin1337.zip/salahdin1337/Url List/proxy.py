import requests,re
urls = ["https://free-proxy-list.net/","https://www.us-proxy.org/","https://free-proxy-list.net/uk-proxy.html","https://www.sslproxies.org/","https://free-proxy-list.net/anonymous-proxy.html"]
proxies = []
for url in urls:
	req = requests.get(url)
	regx = re.findall("<tr><td>(.*?)</td><td>.*?</td><td class='hx'>(.*?)</td>",req.text)
	for proxy in regx:
		if proxy[1] == "yes":
			proxies.append(proxy[0])
			print(proxy[0])
for prox in proxies:
	if prox not in open("proxy.txt","r").read():
		open("proxy.txt","a").write(prox+"\n")