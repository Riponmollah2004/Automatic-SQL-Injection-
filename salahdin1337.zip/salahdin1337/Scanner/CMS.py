try:
	import requests,re,json
	from requests.packages.urllib3.exceptions import InsecureRequestWarning
	requests.packages.urllib3.disable_warnings(InsecureRequestWarning)
except:
	print(" [+] Command: pip install requests")
from os import system,mkdir
from platform import system as osname
def clear():
	if osname() == "Linux":
		system('clear')
	else:
		system('cls')
red = '\x1b[1;31m'
r = '\x1b[31m'
g = '\x1b[32m'
y = '\x1b[33m'
b = '\x1b[34m'
m = '\x1b[35m'
c = '\x1b[36m'
w = '\x1b[37m'
logo = """   _____       _       _         _ _      __ ____ ____ ______ 
  / ____|     | |     | |       | (_)    /_ |___ \___ \____  |
 | (___   __ _| | __ _| |__   __| |_ _ __ | | __) |__) |  / / 
  \___ \ / _` | |/ _` | '_ \ / _` | | '_ \| ||__ <|__ <  / /  
  ____) | (_| | | (_| | | | | (_| | | | | | |___) |__) |/ /   
 |_____/ \__,_|_|\__,_|_| |_|\__,_|_|_| |_|_|____/____//_/                                                              """
def Ret(x):
	try:
		return raw_input(x)
	except:
		return input(x)
try:
	import concurrent.futures
	xxx = True
except:
	from multiprocessing.pool import ThreadPool
	xxx = False
def SpeedX(check,list,th):
	if xxx == True:
		try:
			with concurrent.futures.ThreadPoolExecutor(int(th)) as executor:
				executor.map(check,list)
		except Exception as e:
			print(e)
	else:
		pool = ThreadPool(int(th))
		pool.map(check,list)
		pool.close()
		pool.join()
class CMS:
	settings = []
	headers = {'User-Agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_10_1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/39.0.2171.95 Safari/537.36'}
	def __init__(self):
		self.settings = ["wordpress","joomla","drupal","opencart","laravel","magento","oscommerce","preatshop","vBulletin"]
		try:
			mkdir("cms")
		except:
			pass
	def Run(self,url):
		if "wordpress" in self.settings:
			self.Wordpress(url)
		if "joomla" in self.settings:
			self.Joomla(url)
		if "opencart" in self.settings:
			self.Opencart(url)
		if "drupal" in self.settings:
			self.Drupal(url)
		if "laravel" in self.settings:
			self.Laravel(url)
		if "magento" in self.settings:
			self.Magento(url)
		if "oscommerce" in self.settings:
			self.osCommerce(url)
		if "preatshop" in self.settings:
			self.Preatshop(url)
		if "vBulletin" in self.settings:
			self.vBulletin(url)
	def get(self,url):
		try:
			return requests.get(url,headers=self.headers,timeout=15,verify=False).content.decode('utf-8')
		except:
			return ""
	def save(self,url,file):
		with open(file,"a") as wr:
			wr.write(url+"\n")
	def rez(self,url,exploit,n):
		if n == "1":
			print(w+" ["+g+"+"+w+"] "+g+exploit+": "+w+url+g+" [YES]")
		else:
			print(w+" ["+r+"+"+w+"] "+r+exploit+": "+w+url+r+" [NO]")
	def Wordpress(self,url):
		path = ["/","/wp-includes/js/jquery/jquery.js"]
		for dir in path:
			req = self.get("http://"+url+dir)
			if "/wp-content/" in req or '/wp-includes/' in req:
				self.rez(url,"Wordpress","1")
				self.save(url,"cms/Wordpress.txt")
	def Joomla(self,url):
		path = ["/","/wp-includes/js/jquery/jquery.js"]
		for dir in path:
			req = self.get("http://"+url+dir)
			if "/wp-content/" in req or '/wp-includes/' in req:
				self.rez(url,"Wordpress","1")
				self.save(url,"cms/Wordpress.txt")
	def Drupal(self,url):
		path = ["/","/wp-includes/js/jquery/jquery.js"]
		for dir in path:
			req = self.get("http://"+url+dir)
			if "/wp-content/" in req or '/wp-includes/' in req:
				self.rez(url,"Wordpress","1")
				self.save(url,"cms/Wordpress.txt")
	def Opencart(self,url):
		path = ["/","/wp-includes/js/jquery/jquery.js"]
		for dir in path:
			req = self.get("http://"+url+dir)
			if "/wp-content/" in req or '/wp-includes/' in req:
				self.rez(url,"Wordpress","1")
				self.save(url,"cms/Wordpress.txt")
	def Laravel(self,url):
		path = ["/","/wp-includes/js/jquery/jquery.js"]
		for dir in path:
			req = self.get("http://"+url+dir)
			if "/wp-content/" in req or '/wp-includes/' in req:
				self.rez(url,"Wordpress","1")
				self.save(url,"cms/Wordpress.txt")
	def Magento(self,url):
		path = ["/","/wp-includes/js/jquery/jquery.js"]
		for dir in path:
			req = self.get("http://"+url+dir)
			if "/wp-content/" in req or '/wp-includes/' in req:
				self.rez(url,"Wordpress","1")
				self.save(url,"cms/Wordpress.txt")
	def osCommerce(self,url):
		path = ["/","/wp-includes/js/jquery/jquery.js"]
		for dir in path:
			req = self.get("http://"+url+dir)
			if "/wp-content/" in req or '/wp-includes/' in req:
				self.rez(url,"Wordpress","1")
				self.save(url,"cms/Wordpress.txt")
	def Preatshop(self,url):
		path = ["/","/wp-includes/js/jquery/jquery.js"]
		for dir in path:
			req = self.get("http://"+url+dir)
			if "/wp-content/" in req or '/wp-includes/' in req:
				self.rez(url,"Wordpress","1")
				self.save(url,"cms/Wordpress.txt")
	def vBulletin(self,url):
		path = ["/","/wp-includes/js/jquery/jquery.js"]
		for dir in path:
			req = self.get("http://"+url+dir)
			if "/wp-content/" in req or '/wp-includes/' in req:
				self.rez(url,"Wordpress","1")
				self.save(url,"cms/Wordpress.txt")
obj = CMS()
print(obj.settings)