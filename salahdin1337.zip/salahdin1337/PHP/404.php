<html style="background-color:black">
<head><title>Hacked By @Salahdin1337</title>
<link rel="SHORTCUT ICON" href="https://1.bp.blogspot.com/-jrZKC7uc5NA/YAar8-SLYqI/AAAAAAAAAsc/Nz9SgVmhIGIFY-XE7NWZpkM8fEyuwrPNgCPcBGAsYHg/s0/PicsArt_01-19-02.12.00.png" type="image/png">
<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Iceland">
<meta charset="UTF-8">
<meta name="description" content="Establishing friendship for the sake of Allah and enmity for that.">
<meta name="keywords" content="Black_Phish,Ummah Cyber Mujahideen,Mujahid,Me Black_Phish,MCA-BD,Muslim Cyber Army-BD">
<meta name="author" content="BLACK_PHISH">
<style>
</style>
 </head>
 <body bgcolor="#000000" style="width: auto;">
 <pre style="color:#f72c08;font-size:3.2vw;">   _____       _       _         _ _      __ ____ ____ ______ 
  / ____|     | |     | |       | (_)    /_ |___ \___ \____  |
 | (___   __ _| | __ _| |__   __| |_ _ __ | | __) |__) |  / / 
  \___ \ / _` | |/ _` | '_ \ / _` | | '_ \| ||__ <|__ <  / /  
  ____) | (_| | | (_| | | | | (_| | | | | | |___) |__) |/ /   
 |_____/ \__,_|_|\__,_|_| |_|\__,_|_|_| |_|_|____/____//_/                                                              <br/><br/>  <span style="color:#52cb21">I Don’t Aspect Any Responsibility For illegal Ussage!</span><br/></br><span style="color:yellow"> Author: </span><span style="color:cyan">The Black_Phish</span></br><span style="color:yellow"> Name: </span><span style="color:cyan">Deface Page</span></br><span style="color:yellow"> Application: </span><span style="color:cyan">HTML & CSS</span></br><span style="color:#de08ff"> Chose a Option: </span><br/><span style="color:white">   1. Print My Message <br>   2. Delete All Data</span><br/><br/><span style="color:#52cb21"> [root</span><span style="color:#f72c08">@</span><span style="color:yellow">salahdin</span><span style="color:#52cb21">:</span><span style="color:cyan">~</span><span style="color:#52cb21">]</span><span style="color:#de08ff">#</span><span id="num" style="color:#f72c08"></span><br><text id="content" style="color:white;"></text></pre>
 <script>
 setTimeout(function(){ document.getElementById("num").innerHTML=" 1";}, 1000);
 let txt = "  Congratulations Admin! Your Site Hacked By @Salahdin1337.\n  I Found A Vulnerability In Your System.\n  Your Data Not Safe, Just Say Message For You.\n  Remember Us, We Are Team_ISK. We Are Learner.\n  Establishing friendship for the sake of Allah and enmity for that.\n  And do not say about those who are slain in the cause of Allah\n  that they are dead. (They are not dead.)\n  They are rather alive but you have no perception (of their life).\n  Gretz: Black_Phish, Cybertron RA9, Death Brain, Black_Py, Mr.Dr01D Hack3R";
 let i = 0;
 let y= 0;
 function Print(c,t){
 setTimeout(function(){ document.getElementById("content").innerHTML+=c;},t);
 }
 while(txt[i]){
 y = y+100
 Print(txt[i],1000+y);
 i++;
 }
 </script>
 <img style="display:none" src="https://1.bp.blogspot.com/-jrZKC7uc5NA/YAar8-SLYqI/AAAAAAAAAsc/Nz9SgVmhIGIFY-XE7NWZpkM8fEyuwrPNgCPcBGAsYHg/s0/PicsArt_01-19-02.12.00.png" height=300 weight=300/>
 <iframe src="http://humariweb.com/naats/FQ/Ya-Nabi-Salam-Alaika-(Hamariweb.com).mp3" allow="autoplay" style="display:none;">
 </body>
 </html>